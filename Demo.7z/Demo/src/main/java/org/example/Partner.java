package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class Partner {
    private static JFrame frame;
    private static int selectedPartnerId = -1;
    private static JPanel buttonPanel;
    private static JPanel lastSelectedPanel = null;

    public static void main(String[] args) {

        frame = new JFrame("Partner Interface");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setSize(1200, 800);
        frame.getContentPane().setBackground(Color.decode("#4f4747"));


        buttonPanel = createButtonPanel();
        buttonPanel.setBackground(Color.decode("#F4E8D3"));
        frame.add(buttonPanel, BorderLayout.SOUTH);


        loadPartnersFromDB();

        frame.setVisible(true);
    }

    private static JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton addButton = new JButton("Добавить партнёра");
        JButton editButton = new JButton("Редактировать партнёра");
        JButton historyButton = new JButton("История реализации");


        Color accentColor = Color.decode("#67BA80");
        addButton.setBackground(accentColor);
        addButton.setForeground(Color.WHITE);
        addButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        editButton.setBackground(accentColor);
        editButton.setForeground(Color.WHITE);
        editButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        historyButton.setBackground(accentColor);
        historyButton.setForeground(Color.WHITE);
        historyButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        addButton.addActionListener(e -> openAddPartnerDialog());
        editButton.addActionListener(e -> openEditPartnerDialog());
        historyButton.addActionListener(e -> openSalesHistoryDialog());

        panel.add(addButton);

        panel.add(historyButton);

        return panel;
    }


    private static void loadPartnersFromDB() {
        try (Connection connection = DBConnector.connect()) {
            String query = "SELECT p.id_Партнера, p.\"Тип\", p.\"Наименование_компании\", p.\"Юридический_адрес\", " +
                    "p.\"ИНН\", p.\"ФИО_директора\", p.\"Телефон\", p.\"email\", p.\"Рейтинг\", " +
                    "COALESCE(SUM(s.\"Количество_проданной_продукции\"), 0) AS sales " +
                    "FROM public.\"Партнеры\" p LEFT JOIN public.\"Продажи\" s ON p.id_Партнера = s.id_Партнера " +
                    "GROUP BY p.id_Партнера";

            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);


            frame.getContentPane().removeAll();


            JPanel logoPanel = new JPanel();
            logoPanel.setBackground(Color.decode("#4f4747"));
            ImageIcon logoIcon = new ImageIcon(Partner.class.getClassLoader().getResource("logo.png"));
            if (logoIcon != null) {
                JLabel logoLabel = new JLabel(logoIcon);
                logoPanel.add(logoLabel);
            } else {
                System.out.println("Логотип не найден в папке ресурсов!");
            }


            JPanel partnersPanel = new JPanel();
            partnersPanel.setLayout(new BoxLayout(partnersPanel, BoxLayout.PAGE_AXIS));
            partnersPanel.setBackground(Color.decode("#4f4747"));
            JScrollPane scrollPane = new JScrollPane(partnersPanel);


            frame.add(logoPanel, BorderLayout.NORTH);
            frame.add(scrollPane, BorderLayout.CENTER);
            frame.add(buttonPanel, BorderLayout.SOUTH);


            while (resultSet.next()) {
                int partnerId = resultSet.getInt("id_Партнера");
                String partnerType = resultSet.getString("Тип");
                String companyName = resultSet.getString("Наименование_компании");
                String directorName = resultSet.getString("ФИО_директора");
                String phone = resultSet.getString("Телефон");
                String rating = resultSet.getString("Рейтинг");
                int sales = resultSet.getInt("sales");


                int discount = calculateDiscount(sales);


                JPanel partnerPanel = createPartnerPanel(partnerId, partnerType, companyName, directorName, phone, rating, discount);
                partnersPanel.add(partnerPanel);
                partnersPanel.add(Box.createVerticalStrut(10));
            }

            frame.revalidate();
            frame.repaint();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Ошибка при загрузке данных", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static int calculateDiscount(int sales) {
        int discount = 0;
        if (sales >= 10000 && sales < 50000) {
            discount = 5;
        } else if (sales >= 50000 && sales < 300000) {
            discount = 10;
        } else if (sales >= 300000) {
            discount = 15;
        }
        return discount;
    }


    private static JPanel createPartnerPanel(int partnerId, String type, String name, String director, String phone, String rating, int discount) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(new Dimension(1150, 100));
        panel.setMaximumSize(new Dimension(1150, Integer.MAX_VALUE));
        panel.setMinimumSize(new Dimension(1150, 100));
        panel.setBackground(Color.decode("#4f4747"));

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(Color.decode("#4f4747"));

        Font largeFont = new Font("Segoe UI", Font.BOLD, 16);
        String combinedText = "Тип: " + type + " | " + name;
        JLabel typeAndNameLabel = new JLabel(combinedText);
        typeAndNameLabel.setFont(largeFont);
        contentPanel.add(typeAndNameLabel);

        JLabel directorLabel = new JLabel("Директор: " + director);
        directorLabel.setFont(largeFont);
        contentPanel.add(directorLabel);

        JLabel phoneLabel = new JLabel("Телефон: " + phone);
        phoneLabel.setFont(largeFont);
        contentPanel.add(phoneLabel);

        JLabel ratingLabel = new JLabel("Рейтинг: " + rating);
        ratingLabel.setFont(largeFont);
        contentPanel.add(ratingLabel);


        JPanel percentagePanel = new JPanel();
        percentagePanel.setBackground(Color.decode("#4f4747"));
        JLabel percentageLabel = new JLabel("Скидка: " + discount + "%");
        percentageLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        percentagePanel.add(percentageLabel);


        panel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (lastSelectedPanel != null) {
                    lastSelectedPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
                    lastSelectedPanel.repaint();
                }
                panel.setBorder(BorderFactory.createLineBorder(Color.decode("#67BA80"), 3));
                selectedPartnerId = partnerId;
                lastSelectedPanel = panel;
                panel.repaint();
                openEditPartnerDialog();
            }
        });

        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(percentagePanel, BorderLayout.EAST);

        return panel;
    }


    private static void openEditPartnerDialog() {
        if (selectedPartnerId == -1) {
            JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите партнёра для редактирования.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JDialog dialog = new JDialog(frame, "Редактировать партнёра", true);
        dialog.setLayout(new GridLayout(9, 2));

        try (Connection connection = DBConnector.connect()) {
            String query = "SELECT \"Тип\", \"Наименование_компании\", \"Юридический_адрес\", \"ИНН\", " +
                    "\"ФИО_директора\", \"Телефон\", \"email\", \"Рейтинг\" FROM public.\"Партнеры\" WHERE id_Партнера = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, selectedPartnerId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                JTextField typeField = new JTextField(resultSet.getString("Тип"));
                JTextField nameField = new JTextField(resultSet.getString("Наименование_компании"));
                JTextField addressField = new JTextField(resultSet.getString("Юридический_адрес"));
                JTextField innField = new JTextField(resultSet.getString("ИНН"));
                JTextField directorField = new JTextField(resultSet.getString("ФИО_директора"));
                JTextField phoneField = new JTextField(resultSet.getString("Телефон"));
                JTextField emailField = new JTextField(resultSet.getString("email"));
                JTextField ratingField = new JTextField(resultSet.getString("Рейтинг"));

                dialog.add(new JLabel("Тип"));
                dialog.add(typeField);
                dialog.add(new JLabel("Наименование компании"));
                dialog.add(nameField);
                dialog.add(new JLabel("Юридический адрес"));
                dialog.add(addressField);
                dialog.add(new JLabel("ИНН"));
                dialog.add(innField);
                dialog.add(new JLabel("ФИО директора"));
                dialog.add(directorField);
                dialog.add(new JLabel("Телефон"));
                dialog.add(phoneField);
                dialog.add(new JLabel("Email"));
                dialog.add(emailField);
                dialog.add(new JLabel("Рейтинг"));
                dialog.add(ratingField);

                JButton saveButton = new JButton("Сохранить");
                saveButton.addActionListener(e -> {
                    try {
                        int ratingValue = Integer.parseInt(ratingField.getText());
                        String updateQuery = "UPDATE public.\"Партнеры\" SET \"Тип\" = ?, \"Наименование_компании\" = ?, " +
                                "\"Юридический_адрес\" = ?, \"ИНН\" = ?, \"ФИО_директора\" = ?, \"Телефон\" = ?, " +
                                "\"email\" = ?, \"Рейтинг\" = ? WHERE id_Партнера = ?";
                        PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                        updateStatement.setString(1, typeField.getText());
                        updateStatement.setString(2, nameField.getText());
                        updateStatement.setString(3, addressField.getText());
                        updateStatement.setString(4, innField.getText());
                        updateStatement.setString(5, directorField.getText());
                        updateStatement.setString(6, phoneField.getText());
                        updateStatement.setString(7, emailField.getText());
                        updateStatement.setInt(8, ratingValue);
                        updateStatement.setInt(9, selectedPartnerId);

                        updateStatement.executeUpdate();
                        JOptionPane.showMessageDialog(dialog, "Данные партнёра обновлены.");
                        dialog.dispose();
                        loadPartnersFromDB();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(dialog, "Ошибка при обновлении данных", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(dialog, "Рейтинг должен быть числом", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    }
                });

                dialog.add(saveButton);
                dialog.setSize(400, 300);
                dialog.setVisible(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Ошибка при загрузке данных партнёра.", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }


    private static void openAddPartnerDialog() {
        JDialog dialog = new JDialog(frame, "Добавить партнёра", true);
        dialog.setLayout(new GridLayout(9, 2));

        JTextField typeField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField innField = new JTextField();
        JTextField directorField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField ratingField = new JTextField();

        dialog.add(new JLabel("Тип"));
        dialog.add(typeField);
        dialog.add(new JLabel("Наименование компании"));
        dialog.add(nameField);
        dialog.add(new JLabel("Юридический адрес"));
        dialog.add(addressField);
        dialog.add(new JLabel("ИНН"));
        dialog.add(innField);
        dialog.add(new JLabel("ФИО директора"));
        dialog.add(directorField);
        dialog.add(new JLabel("Телефон"));
        dialog.add(phoneField);
        dialog.add(new JLabel("Email"));
        dialog.add(emailField);
        dialog.add(new JLabel("Рейтинг"));
        dialog.add(ratingField);

        JButton saveButton = new JButton("Сохранить");
        saveButton.addActionListener(e -> {
            try {
                int ratingValue;
                try {
                    ratingValue = Integer.parseInt(ratingField.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Рейтинг должен быть числом", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try (Connection connection = DBConnector.connect()) {
                    String query = "INSERT INTO public.\"Партнеры\" (\"Тип\", \"Наименование_компании\", \"Юридический_адрес\", \"ИНН\", " +
                            "\"ФИО_директора\", \"Телефон\", \"email\", \"Рейтинг\") VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, typeField.getText());
                    statement.setString(2, nameField.getText());
                    statement.setString(3, addressField.getText());
                    statement.setString(4, innField.getText());
                    statement.setString(5, directorField.getText());
                    statement.setString(6, phoneField.getText());
                    statement.setString(7, emailField.getText());
                    statement.setInt(8, ratingValue);

                    statement.executeUpdate();
                    JOptionPane.showMessageDialog(frame, "Партнёр добавлен.");
                    loadPartnersFromDB();
                    dialog.dispose();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Ошибка при добавлении партнёра", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        dialog.add(saveButton);
        dialog.setSize(400, 300);
        dialog.setVisible(true);
    }


    static class PartnerItem {
        private int id;
        private String name;
        public PartnerItem(int id, String name) {
            this.id = id;
            this.name = name;
        }
        public int getId() {
            return id;
        }
        @Override
        public String toString() {
            return name;
        }
    }

    private static void openSalesHistoryDialog() {

        JDialog dialog = new JDialog(frame, "История реализации", true);
        dialog.setLayout(new BorderLayout());


        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topPanel.setBackground(Color.decode("#F4E8D3"));
        JLabel selectLabel = new JLabel("Выберите партнёра:");
        selectLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        topPanel.add(selectLabel);

        JComboBox<PartnerItem> partnerComboBox = new JComboBox<>();
        partnerComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));


        try (Connection connection = DBConnector.connect()) {
            String query = "SELECT id_Партнера, \"Наименование_компании\" FROM public.\"Партнеры\"";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                int id = rs.getInt("id_Партнера");
                String companyName = rs.getString("Наименование_компании");
                partnerComboBox.addItem(new PartnerItem(id, companyName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(dialog, "Ошибка при загрузке списка партнёров.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }
        topPanel.add(partnerComboBox);

        JButton showHistoryButton = new JButton("Показать историю");
        showHistoryButton.setBackground(Color.decode("#67BA80"));
        showHistoryButton.setForeground(Color.WHITE);
        showHistoryButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        topPanel.add(showHistoryButton);


        String[] columnNames = {"Наименование продукции", "Количество", "Дата продажи"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setRowHeight(25);
        table.setBackground(Color.decode("#4f4747"));
        table.getTableHeader().setBackground(Color.decode("#67BA80"));
        JScrollPane scrollPane = new JScrollPane(table);


        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(scrollPane, BorderLayout.CENTER);


        showHistoryButton.addActionListener(e -> {
            PartnerItem selectedPartner = (PartnerItem) partnerComboBox.getSelectedItem();
            if (selectedPartner == null) {
                JOptionPane.showMessageDialog(dialog, "Пожалуйста, выберите партнёра.", "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int partnerId = selectedPartner.getId();

            tableModel.setRowCount(0);

            try (Connection connection = DBConnector.connect()) {
                String query = "SELECT \"Продукция\", \"Количество_проданной_продукции\", \"Дата_продажи\" " +
                        "FROM public.\"Продажи\" WHERE \"id_Партнера\" = ?";
                PreparedStatement stmt = connection.prepareStatement(query);
                stmt.setInt(1, partnerId);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    String productName = rs.getString("Продукция");
                    int quantity = rs.getInt("Количество_проданной_продукции");
                    java.sql.Date saleDate = rs.getDate("Дата_продажи");
                    tableModel.addRow(new Object[]{productName, quantity, saleDate});
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "Ошибка при загрузке истории продаж.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

}
