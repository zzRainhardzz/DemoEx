package org.example;

public class Production {

    public static int calculateRequiredMaterial(int productTypeId, int materialTypeId, int productQuantity, double param1, double param2) {

        if (productTypeId <= 0 || materialTypeId <= 0 || productQuantity <= 0 || param1 <= 0 || param2 <= 0) {
            return -1;
        }


        double productTypeCoefficient;
        switch (productTypeId) {
            case 1:
                productTypeCoefficient = 1.1;
                break;
            case 2:
                productTypeCoefficient = 1.2;
                break;
            default:
                return -1;
        }


        double materialWastePercent;
        switch (materialTypeId) {
            case 1:
                materialWastePercent = 5.0;
                break;
            case 2:
                materialWastePercent = 10.0;
                break;
            default:
                return -1;
        }


        double materialPerUnit = param1 * param2 * productTypeCoefficient;

        double totalMaterial = productQuantity * materialPerUnit * (1 + materialWastePercent / 100);


        return (int) Math.ceil(totalMaterial);
    }
}
